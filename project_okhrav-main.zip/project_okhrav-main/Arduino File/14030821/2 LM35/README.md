#

[ نمایش دما با LM35](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/2%20LM35/LM35.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/19_lm35.jpeg" alt="LM35" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
*  سنسور LM35
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/19_lm35.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/2%20LM35/LM35.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید سنسور LM35 دمالی محیط را دریافت و در سریال مانیتور نمایش دهد.

