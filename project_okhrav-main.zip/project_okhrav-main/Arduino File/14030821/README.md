# گزارش کار های جلسه 21 آبان 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1 پیانو](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/1%20PIANO)

[آزمایش 2 نمایش دما با LM35](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/2%20LM35)

[آزمایش 3 دما و رطوبت با DHT11](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/3%20DHT11)
