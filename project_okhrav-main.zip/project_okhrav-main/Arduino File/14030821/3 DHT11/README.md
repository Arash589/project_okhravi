#

[ دما و رطوبت با DHT11](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/3%20DHT11/DHT11.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/20_DHT11.jpeg" alt="DHT11" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
*  سنسور DHT11
*  مقاومت 10 کیلو اهم
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/20_DHT11.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/3%20DHT11/DHT11.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید سنسور DHT11 دمای محیط و رطوبت را دریافت و در سریال مانیتور نمایش دهد.

