#

[ پیانو](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/1%20PIANO/PIANO.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/18_piano.jpeg" alt="PIANO" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
* پوش باتن به تعداد لازم
* برد بورد
* اسپیکر نیم وات
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/18_piano.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030821/1%20PIANO/PIANO.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید با فشردن هر یکی از پوش باتن ها یک صدا از اسپیکر خارج شود.

