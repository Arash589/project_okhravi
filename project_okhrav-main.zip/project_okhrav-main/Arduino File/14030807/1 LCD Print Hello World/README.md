#

[راه اندازی ال سی دی کاراکتری](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030807/1%20LCD%20Print%20Hello%20World/LCD%20Print%20Hello%20World.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/12LCDprinthello.jpeg" alt="LCD Hello" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
* ال سی دی کارکتری 16*2
* برد بورد
* پتاسیومتر
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ


 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق شماتیک موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030807/1%20LCD%20Print%20Hello%20World/LCD%20Print%20Hello%20World.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید ال سی دی کاراکتری به ما پیغام !!!Hello World را نمایش دهد.
