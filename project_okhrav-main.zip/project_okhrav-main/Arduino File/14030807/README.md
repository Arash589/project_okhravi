# گزارش کار های جلسه 07 آبان 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1 راه اندازی ال سی دی کاراکتری](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030807/1%20LCD%20Print%20Hello%20World)

[آزمایش 2 نمایش آدمک روی ال سی دی](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030807/2%20LCD%20Show%20Character)

[آزمایش 3 سنسور التراسونیک](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030807/3%20UltraSonic)
