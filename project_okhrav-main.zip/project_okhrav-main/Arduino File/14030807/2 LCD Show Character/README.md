#

 [نمایش آدمک روی ال سی دی](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030807/2%20LCD%20Show%20Character/LCD%20Show%20Character.ino)


<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/13_LCD_Show_Character.png" alt="LCD Hello" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
* ال سی دی کارکتری 16*2
* برد بورد
* پتاسیومتر
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ


 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق شماتیک موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030807/2%20LCD%20Show%20Character/LCD%20Show%20Character.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید ال سی دی کاراکتری به ما آدمکی را نشان دهد که در ابتدا از سمت چپ ال سی دی به سمت راست یکی درمیان در خانه های ال سی دی دستش بالا و پایین می رود به صورت زیر :
 
<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Video/13_LCD_Show_Character.gif" alt="LCD Hello" />
</p>
