# گزارش کار های جلسه 5 آذر 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1  راه اندازی کیپد 4 در 4](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030905/1%20Keypad%20Launch)

[آزمایش 2 ماشین حساب با کیپد ](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030905/2%20Calculator%20With%20Keypad)

[آزمایش 3 راه اندازی جوی استیک ](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030905/3%20Joystick%20Launch)

[آزمایش 4 تغییر وضعیت ال ای دی با جوی استیک](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030905/4%20Joystick%20LED%20Reaction)
