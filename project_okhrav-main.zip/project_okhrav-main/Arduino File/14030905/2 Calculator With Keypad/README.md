#

[ ماشین حساب با کیپد ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030905/2%20Calculator%20With%20Keypad/Calculator%20With%20Keypad.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/26_Calculator_With_Keypad.jpeg" alt="Keypad Calculator" />
</p>


# ابزار و وسایل مورد نیاز :
* 1 عدد برد آردوینو UNO R3
* 1 عدد کیپد 4 در 4
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/26_Calculator_With_Keypad.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030905/1%20Keypad%20Launch/Keypad%20Launch.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند می توان اعداد را جمع ، تفریق ، ضرب و تفسیم کرد و حاصل را در سریال ماینتور دید.

