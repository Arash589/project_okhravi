#

[ راه اندازی جوی استیک ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030905/3%20Joystick%20Launch/Joystick%20Launch.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/27_Joystick_Launch.jpeg" alt="Joystick Launch" />
</p>


# ابزار و وسایل مورد نیاز :
* 1 عدد برد آردوینو UNO R3
* 1 عدد جوی استیک آنالوگ
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/27_Joystick_Launch.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030905/3%20Joystick%20Launch/Joystick%20Launch.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید با تغییر حالت جوی استیک مقادیر آن در سریال مانیتور نمایش داده شود.

