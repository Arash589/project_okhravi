#

[ اتصال دو برد آردوینو و روشن شدن به همراه پتاسومتر](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/1%20Master_Slave%20POT/Slave.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/21_MS.jpeg" alt="Master_Slave" />
</p>


# ابزار و وسایل مورد نیاز :
* 2 عدد برد آردوینو UNO R3
* 2 عدد پتاسیومتر
* 2 عدد ال ای دی
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/21_MS.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/1%20Master_Slave%20POT/Slave.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید با چرخاندن پتاسیومتر سمت اسلیو چراغ سمت مستر تغییر کند و با چرخاندن پتاسیومتر سمت مستر چراغ سمت اسلیو تغییر کند.

