#

[ اتصال دو برد آردوینو و روشن شدن به همراه پتاسومتر](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/3%20L298N/L298N.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/23_L298n.jpeg" alt="L298" />
</p>


# ابزار و وسایل مورد نیاز :
* 1 عدد برد آردوینو UNO R3
* ماژول L298N
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/23_L298n.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/3%20L298N/L298N.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند باید با موتور DC شروع به حرکت کند و سرعتش کم و زیاد شود وجهت چرخشش تغییر کند.

