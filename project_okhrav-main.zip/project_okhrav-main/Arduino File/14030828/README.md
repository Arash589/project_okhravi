# گزارش کار های جلسه 28 آبان 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1  اتصال دو برد آردوینو و روشن شدن با پتاسومتر](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/1%20Master_Slave%20POT)

[آزمایش 2 اتصال دو برد آردوینو و روشن شدن با دستور سریال](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/2%20Master_Slave%20Serial)

[آزمایش 3 راه اندازی موتور DC با L298N](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030828/3%20L298N)

[آزمایش 4 راه اندازی موتور DC با L298N با پتاسومتر](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030828/4%20L298N%20POT)
