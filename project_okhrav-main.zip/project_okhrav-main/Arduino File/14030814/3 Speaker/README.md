#

[اتصال اسپیکر به برد و پخش قطعه آهنگ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/3%20Speaker/Speaker.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/17_Speaker.jpeg" alt="Speaker" />
</p>


# ابزار و وسایل مورد نیاز :
* برد آردوینو UNO R3
* اسپیکر نیم وات
* کامپیوتر یا لپ تاپ


 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق شماتیک موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/3%20Speaker/Speaker.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم. نکته ای که وجود دارد این است که ما نوت ها در فایل [pitches.h](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/3%20Speaker/pitches.h) قرار داده ایم و سپس این فایل را در کد اصلی include کرده ایم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند یک قطعه آهنگ به صورت مداوم پخش می شود.
