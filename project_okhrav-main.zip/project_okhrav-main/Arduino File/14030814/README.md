# گزارش کار های جلسه 14 آبان 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1 راه اندازی سون سگمنت](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/1%20SevenSegment)

[آزمایش 2 راه اندازی سنسور فتوسل](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/2%20Photocell)

[آزمایش 3 اتصال اسپیکر به برد و پخش قطعه آهنگ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030814/3%20Speaker)
