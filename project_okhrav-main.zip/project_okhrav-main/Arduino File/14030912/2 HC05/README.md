#

[ راه اندازی ماژول بلوتوث HC05 ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030912/2%20HC05/HC05.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/30_HC05.jpeg" alt="HC05" />
</p>


# ابزار و وسایل مورد نیاز :
* 1 عدد برد آردوینو UNO R3
* 1 عدد ماژول سنسور HC05
* 1 عدد ال ای دی 
* برد بورد
* سیم مخابراتی به تعداد لازم
* کامپیوتر یا لپ تاپ

 # شرح آزمایش : 
 در ابتدا ابزار و وسایل مورد نیاز را تهیه می کنیم و طبق [شماتیک](https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/30_HC05.jpeg) موجود آن ها را به کمک برد بورد به برد آردوینو متصل می کنیم ، سپس در کامپیوتر به کمک نرم افزار Arduino IDE کدی در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/14030912/2%20HC05/HC05.ino) قرار دارد را روی برد آردوینو UNO R3 پروگرام می کنیم.
 بعد از پروگرام کردن کد اگر اتصالات به درستی متصل شده باشند و قطعات مشکلی نداشته باشند می توان به بلوتوث ماژول متصل شد و از طرق ارسال فرمان از طریق نرم افزار BT Terminal فرمان ON یا OFF فرستاد و ال ای دی را روشن و خاموش کرد.

