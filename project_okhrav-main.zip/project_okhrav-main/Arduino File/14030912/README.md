# گزارش کار های جلسه 12 آذر 1403 
(برای مشاهده هر یک روی آن کلیک کنید)

[آزمایش 1  راه اندازی سنسور HW201](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030912/1%20HW201)

[آزمایش 2 راه اندازی ماژول بلوتوث HC05 ](https://github.com/mohsenkmt/MicroProcessor/tree/main/Arduino%20File/14030912/2%20HC05)


