[چشمک زن](https://github.com/mohsenkmt/Micro-Processor/blob/main/Arduino%20File/1_one_led_blinker.ino#L12)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Video/1_one_led_blinker.gif" alt="LED Blinker" />
</p>

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/raw/main/Photo/1_one_led_blinker.png" alt="LED Blinker" />
</p>


در برد آردوینو یک LED طراحی شده است که به پایه 13 دیجیتال متصل است و ما با کدی که در [اینجا](https://github.com/mohsenkmt/Micro-Processor/blob/main/Arduino%20File/1_one_led_blinker.ino#L12)  قرار دارد آن را خاموش رو روشن می کنیم که حالت چشمک زن داشتنه باشد . این کد اولین کد و ساده ترین کد برای تست و راه اندازی برد آردوینو می باشد.
همچنین می توانیم به جای استفاده از ال ای دی روی برد ، یک ال ای دی دیگر به پایه 13 متصل کنیم:

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/raw/main/Photo/1_one_led_blinker1.jpeg" alt="LED Blinker" />
</p>
