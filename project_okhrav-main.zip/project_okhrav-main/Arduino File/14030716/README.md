[چشمک زن با دو عدد LED](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/2_Two_Led_Blinker.ino)
<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/2_Two_Led_Blinker.jpeg" alt="Two LED Blinker" />
</p>


در این کد که در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/2_Two_Led_Blinker.ino) قرار دارد 2 عدد LED را به طور یکی در میان خاموش و روشن می کنیم.
#
[خاموش و روشن کردن LED با ارسال پیام سریال](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/3_On_Off_Led_By_Serial.ino)

<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/3_On_Off_Led_By_Serial.jpeg" alt="On Off Led By Serial " />
</p>

در این کد که در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/3_On_Off_Led_By_Serial.ino) است می توانیم با فرستادن پیام به صورت سریال به برد ال ای دی روی برد را روشن یا خاموش کنیم.

#

[ماشین حساب ](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/4_Calculator_Serial.ino)
<p align="center">
  <img src="https://github.com/mohsenkmt/MicroProcessor/blob/main/Photo/4_Calculator_Serial.jpeg" alt="Calculator Serial " />
</p>

در این کد که در [اینجا](https://github.com/mohsenkmt/MicroProcessor/blob/main/Arduino%20File/4_Calculator_Serial.ino) است می توان چهار عمل اصلی جمع و تفریق ، ضرب و تفسیم را برای برد فرستاد و جواب را دریافت کرد.
