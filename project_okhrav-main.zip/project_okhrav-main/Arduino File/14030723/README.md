[نمودار سینوس ، کسیسنوس ](https://github.com/Arash589/project_okhravi/blob/main/Arduino%20File/5_Sin_Cos.ino)

<p align="center">
  <img src="https://github.com/Arash589/project_okhravi/blob/main/Photo/5_Sin_Cos1.jpeg" alt="Sin,Cos" />
</p>

در این کد که در [اینجا](https://github.com/Arash589/project_okhravi/blob/main/Arduino%20File/5_Sin_Cos.ino) قرار دارد می توان نمودار سینوس و کسیسنوس را در Serial Ploter نشان داد.
<p align="center">
  <img src="https://github.com/Arash589/project_okhravi/blob/main/Photo/5_Sin_Cos.jpeg" alt="Sin,Cos" />
</p>

#
[روشن شدن ال ای دی با کلید ](https://github.com/Arash589/project_okhravi/blob/main/Arduino%20File/6_Pushbutton_LED_ON_OFF.ino)
<p align="center">
  <img src="https://github.com/Arash589/project_okhravi/blob/main/Video/6_Pushbutton_LED_ON_OFF.gif" alt="Pushbutton LED ON OFF" />
</p>

در این کد که در [اینجا](https://github.com/Arash589/project_okhravi/blob/main/Arduino%20File/6_Pushbutton_LED_ON_OFF.ino) است می توان بوسیله یک کلید ال ای دی را روشن کرد.
<p align="center">
  <img src="https://github.com/Arash589/project_okhravi/blob/main/Photo/6_Pushbutton_LED_ON_OFF.jpeg" alt="Pushbutton LED ON OFF" />
</p>
